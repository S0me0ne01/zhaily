from django import forms
from .models import *

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from django.core import validators
from django.core.validators import FileExtensionValidator


KINDS = [
    ('usual', 'Для обычных клиентов'),
    ('corporate', 'Для корпоративных клиентов'),
]


class FoodCategoryForm(forms.ModelForm):
    name = forms.CharField(label = 'Название на русском')
    name_kz = forms.CharField(label = 'Название на казахском')
    image = forms.ImageField(label = 'Изображение', validators=[FileExtensionValidator(allowed_extensions=('png', 'jpg', 'jpeg'))], error_messages={'invalid_extension' : 'Этот формат не поддерживается', 'required' : ''}, required = True)

    class Meta:
        model = FoodCategory
        fields = ('name', 'name_kz', 'image',)


class DrinkCategoryForm(forms.ModelForm):
    name = forms.CharField(label = 'Название на русском')
    name_kz = forms.CharField(label = 'Название на казахском')
    image = forms.ImageField(label = 'Изображение', validators=[FileExtensionValidator(allowed_extensions=('png', 'jpg', 'jpeg'))], error_messages={'invalid_extension' : 'Этот формат не поддерживается', 'required' : ''}, required = True)

    class Meta:
        model = DrinkCategory
        fields = ('name', 'name_kz', 'image',)


class FoodForm(forms.ModelForm):
    name = forms.CharField(label = 'Название на русском')
    name_kz = forms.CharField(label = 'Название на казахском')
    description = forms.CharField(label = 'Описание на русском', widget=forms.widgets.Textarea(), required = False)
    description_kz = forms.CharField(label = 'Описание на казахском', widget=forms.widgets.Textarea(), required = False)
    compound = forms.CharField(label = 'Состав на русском', widget=forms.widgets.Textarea(), required = False)
    compound_kz = forms.CharField(label = 'Состав на казахском', widget=forms.widgets.Textarea(), required = False)

    prices = forms.CharField(label = 'Цена(ы)')
    sizes = forms.CharField(label = 'Размер(ы)')
    image = forms.ImageField(label = 'Изображение', validators=[FileExtensionValidator(allowed_extensions=('png', 'jpg', 'jpeg'))], error_messages={'invalid_extension' : 'Этот формат не поддерживается', 'required' : ''}, required = False)

    kind = forms.ChoiceField(label = 'Тип', widget=forms.Select, choices = KINDS)
    category = forms.ModelChoiceField(queryset = FoodCategory.objects.all(), label = "Категория", empty_label = None, error_messages={'required': 'Выберите категорию'}, widget=forms.widgets.Select(attrs={'size': 8}))

    class Meta:
        model = Food
        fields = ('name', 'name_kz', 'description', 'description_kz', 'compound', 'compound_kz', 'prices', 'sizes', 'image', 'kind', 'category',)


class DrinkForm(forms.ModelForm):
    name = forms.CharField(label = 'Название на русском')
    name_kz = forms.CharField(label = 'Название на казахском')

    prices = forms.CharField(label = 'Цена(ы)')
    sizes = forms.CharField(label = 'Размер(ы)')
    image = forms.ImageField(label = 'Изображение', validators=[FileExtensionValidator(allowed_extensions=('png', 'jpg', 'jpeg'))], error_messages={'invalid_extension' : 'Этот формат не поддерживается', 'required' : ''}, required = False)

    kind = forms.ChoiceField(label = 'Тип', widget=forms.Select, choices = KINDS)
    category = forms.ModelChoiceField(queryset = DrinkCategory.objects.all(), label = "Категория", empty_label = None, error_messages={'required': 'Выберите категорию'}, widget=forms.widgets.Select(attrs={'size': 8}))

    class Meta:
        model = Drink
        fields = ('name', 'name_kz', 'prices', 'sizes', 'image', 'kind', 'category',)


class LoginForm(forms.Form):
    username = forms.CharField(label = 'Ваш никнейм')
    password = forms.CharField(label = 'Ваш пароль', widget=forms.PasswordInput)
