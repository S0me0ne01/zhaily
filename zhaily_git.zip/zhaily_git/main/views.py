from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.models import User, UserManager
from django.contrib.auth.forms import UserCreationForm

from .models import *
from .forms import *

import time
import datetime
import requests
import telegram

from django.contrib.auth import authenticate, login
from django.contrib.auth.views import redirect_to_login
from django.contrib.auth.mixins import LoginRequiredMixin

from django.http import HttpResponseRedirect, HttpRequest, HttpResponseForbidden, HttpResponse, HttpResponseNotFound, Http404
from django.urls import reverse

from django.template import RequestContext

from django.core.paginator import Paginator
from django.core.mail import send_mail


def homepage(request):
    language = request.COOKIES.get('language')
    if not language:
        language = 'ru'

    f_categories = FoodCategory.objects.all()
    d_categories = DrinkCategory.objects.all()
    u_food = Food.objects.filter(kind = 'usual')
    c_food = Food.objects.filter(kind = 'corporate')
    u_drinks = Drink.objects.filter(kind = 'usual')
    c_drinks = Drink.objects.filter(kind = 'corporate')

    adress = request.META.get('HTTP_X_FORWARDED_FOR')
    if adress:
        ip = adress.split(',')[-1].strip()
    else:
        ip = request.META.get('REMOTE_ADDR')

    try:
        visit = get_object_or_404(Visit, year = datetime.datetime.now().year, month = datetime.datetime.now().month)
        if ip not in visit.visited:
            visit.visited = visit.visited + ' ' + ip
            visit.visits += 1
            visit.save()
    except Http404:
        Visit.objects.create(visited = ip, visits = 1)

    context = {'language' : language, 'f_categories' : f_categories, 'd_categories': d_categories, 'u_food' : u_food, 'c_food' : c_food, 'u_drinks' : u_drinks, 'c_drinks' : c_drinks}
    return render(request, 'homepage.html', context)


def corporate(request):
    language = request.COOKIES.get('language')
    if not language:
        language = 'ru'

    f_categories = FoodCategory.objects.all()
    d_categories = DrinkCategory.objects.all()
    c_food = Food.objects.filter(kind = 'corporate')
    c_drinks = Drink.objects.filter(kind = 'corporate')

    context = {'language' : language, 'f_categories' : f_categories, 'd_categories': d_categories, 'c_food' : c_food, 'c_drinks' : c_drinks}
    return render(request, 'corporate.html', context)


def categories(request):
    if request.user.is_staff:
        language = request.COOKIES.get('language')
        if not language:
            language = 'ru'

        f_categories = FoodCategory.objects.all()
        d_categories = DrinkCategory.objects.all()

        context = {'language' : language, 'f_categories' : f_categories, 'd_categories': d_categories}
        return render(request, 'categories.html', context)
    else:
        return HttpResponseNotFound()


def add(request, kind):
    if request.user.is_staff:
        language = request.COOKIES.get('language')
        if not language:
            language = 'ru'

        f_categories = FoodCategory.objects.all()
        d_categories = DrinkCategory.objects.all()

        if kind == 'food':
            form_type = FoodForm
        elif kind == 'drink':
            form_type = DrinkForm
        elif kind == 'f_category':
            form_type = FoodCategoryForm
        elif kind == 'd_category':
            form_type = DrinkCategoryForm
        else:
            context = {'language' : language, 'f_categories' : f_categories, 'd_categories' : d_categories}
            return render(request, 'add_choose.html', context)

        if request.method == "POST":
            f = form_type(request.POST, request.FILES)
            if f.is_valid():
                f = f.save(commit = False)
                f.save()
                return redirect(request.META['HTTP_REFERER'])
            else:
                context = {'language' : language, 'f_categories' : f_categories, 'd_categories' : d_categories, 'form' : f}
                return render(request, 'add.html', context)
        else:
            f = form_type()
            context = {'language' : language, 'f_categories' : f_categories, 'd_categories' : d_categories, 'kind' : kind, 'form' : f}
            return render(request, 'add.html', context)
    else:
        return HttpResponseNotFound()


def edit(request, kind, object_id):
    if request.user.is_staff:
        language = request.COOKIES.get('language')
        if not language:
            language = 'ru'

        f_categories = FoodCategory.objects.all()
        d_categories = DrinkCategory.objects.all()

        if kind == 'food':
            form_type = FoodForm
            object = get_object_or_404(Food, id = object_id)
        elif kind == 'drink':
            form_type = DrinkForm
            object = get_object_or_404(Drink, id = object_id)
        elif kind == 'f_category':
            form_type = FoodCategoryForm
            object = get_object_or_404(FoodCategory, id = object_id)
        elif kind == 'd_category':
            form_type = DrinkCategoryForm
            object = get_object_or_404(DrinkCategory, id = object_id)
        else:
            return HttpResponseNotFound()

        if request.method == "POST":
            f = form_type(request.POST, request.FILES, instance = object)
            if f.is_valid():
                f = f.save(commit = False)
                f.save()
                return redirect(request.META['HTTP_REFERER'])
            else:
                context = {'language' : language, 'f_categories' : f_categories, 'd_categories' : d_categories, 'form' : f}
                return render(request, 'edit.html', context)
        else:
            f = form_type(instance = object)
            context = {'language' : language, 'f_categories' : f_categories, 'd_categories' : d_categories, 'form' : f}
            return render(request, 'edit.html', context)
    else:
        return HttpResponseNotFound()


def delete(request, kind, object_id):
    if request.user.is_staff:
        language = request.COOKIES.get('language')
        if not language:
            language = 'ru'

        if kind == 'food':
            object = get_object_or_404(Food, id = object_id)

        elif kind == 'drink':
            object = get_object_or_404(Drink, id = object_id)

        elif kind == 'f_category':
            object = get_object_or_404(FoodCategory, id = object_id)

        elif kind == 'd_category':
            object = get_object_or_404(DrinkCategory, id = object_id)

        else:
            return HttpResponseNotFound()

        if object.image:
            object.image.delete()
        object.delete()

        return redirect(request.META['HTTP_REFERER'])
    else:
        return HttpResponseNotFound


def statistics(request):
    if request.user.is_staff:
        language = request.COOKIES.get('language')
        if not language:
            language = 'ru'

        f_categories = FoodCategory.objects.all()
        d_categories = DrinkCategory.objects.all()
        visits = Visit.objects.order_by('-year', '-month')

        context = {'language' : language, 'f_categories' : f_categories, 'd_categories' : d_categories, 'visits' : visits}
        return render(request, 'statistics.html', context)
    else:
        return HttpResponseNotFound()


def language_change(request, new_language):
    response = redirect(request.META['HTTP_REFERER'])
    if new_language == 'kz' or new_language == 'ru':
        response.set_cookie('language', new_language)
    return response


def user_login(request):
    language = request.COOKIES.get('language')
    if not language:
        language = 'ru'

    f_categories = FoodCategory.objects.all()
    d_categories = DrinkCategory.objects.all()

    if request.method == 'POST':
        lf = LoginForm(request.POST)
        if lf.is_valid():
            cd = lf.cleaned_data
            user = authenticate(username=cd['username'], password=cd['password'])
            if user is not None:
                if user.is_active:
                    login(request, user)
                    return HttpResponseRedirect(reverse('main:homepage', args = ()))
                else:
                    return HttpResponse('Ошибка аккаунта')
            else:
                return HttpResponse('Некорректные данные')
        else:
            context = {'language' : language, 'form' : lf, 'f_categories' : f_categories, 'd_categories' : d_categories}
            response = render(request, 'login.html', context)
            response.set_cookie('language', language)
            return response
    else:
        lf = LoginForm()
        context = {'language' : language, 'form' : lf, 'f_categories' : f_categories, 'd_categories' : d_categories}
        response = render(request, 'login.html', context)
        response.set_cookie('language', language)
        return response
