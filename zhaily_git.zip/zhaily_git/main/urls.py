from django.contrib import admin
from django.urls import path

from .views import *

from django.contrib.auth.views import LoginView, LogoutView

app_name = 'main'

urlpatterns = [
    #Authentication
    path('zhailylogin/', user_login, name = 'login'),
    path('logout/', LogoutView.as_view(next_page='main:homepage', template_name = "logged_out.html"), name = 'logout'),
    #Homepage
    path('', homepage, name = 'homepage'),
    path('corporate/', corporate, name = 'corporate'),
    #Categories
    path('categories', categories, name = 'categories'),
    #Add|Edit|Delete
    path('add/<str:kind>/', add, name = 'add'),
    path('add/', add, kwargs={'kind': None}, name = 'add'),
    path('edit/<str:kind>/<str:object_id>/', edit, name = 'edit'),
    path('delete/<str:kind>/<str:object_id>/', delete, name = 'delete'),
    #Statistics
    path('statistics/', statistics, name = 'statistics'),
    #Language
    path('language/change/<str:new_language>/', language_change, name = 'language_change'),
]
